let blendValue = 50;
let isDay = true;
let cityBuildings = [];
let trees = [];
let stars = [];
let clouds = [];

function setup() {
    let canvas = createCanvas(800, 500);
    canvas.parent('canvas-container');
    
    // Configura controles
    document.getElementById('blend-slider').addEventListener('input', function() {
        blendValue = parseInt(this.value);
    });
    
    document.getElementById('toggle-view').addEventListener('click', function() {
        isDay = !isDay;
        if (isDay) {
            this.textContent = "Ver Noite";
        } else {
            this.textContent = "Ver Dia";
        }
    });
    
    // Cria edifícios da cidade
    for (let i = 0; i < 10; i++) {
        cityBuildings.push({
            x: random(width * 0.4, width * 0.9),
            width: random(30, 80),
            height: random(100, 300),
            windows: floor(random(5, 15))
        });
    }
    
    // Cria árvores do campo
    for (let i = 0; i < 15; i++) {
        trees.push({
            x: random(width * 0.1, width * 0.4),
            y: height - 50,
            size: random(30, 70),
            leaves: floor(random(3, 8))
        });
    }
    
    // Cria estrelas para a noite
    for (let i = 0; i < 100; i++) {
        stars.push({
            x: random(width),
            y: random(height * 0.6),
            size: random(1, 3),
            brightness: random(100, 255)
        });
    }
    
    // Cria nuvens
    for (let i = 0; i < 5; i++) {
        clouds.push({
            x: random(width),
            y: random(height * 0.3),
            speed: random(0.2, 0.8),
            size: random(50, 120)
        });
    }
}

function draw() {
    // Fundo gradiente baseado no blendValue
    let skyColor = isDay ? color(135, 206, 235) : color(10, 10, 50);
    let groundColor = isDay ? color(139, 69, 19, 150) : color(20, 20, 60, 150);
    
    // Aplica o blend entre campo e cidade
    let blendFactor = blendValue / 100;
    
    // Céu
    background(lerpColor(color(34, 139, 34, 50), skyColor, blendFactor));
    
    // Sol/Lua
    if (isDay) {
        fill(255, 255, 0);
        noStroke();
        ellipse(width * 0.8, height * 0.2, 60, 60);
    } else {
        fill(220, 220, 220);
        noStroke();
        ellipse(width * 0.8, height * 0.2, 50, 50);
        
        // Desenha estrelas
        for (let star of stars) {
            fill(255, 255, 255, star.brightness);
            ellipse(star.x, star.y, star.size, star.size);
        }
    }
    
    // Nuvens (movem-se)
    fill(255, 255, 255, 200);
    for (let i = 0; i < clouds.length; i++) {
        let cloud = clouds[i];
        ellipse(cloud.x, cloud.y, cloud.size, cloud.size * 0.6);
        ellipse(cloud.x + cloud.size * 0.3, cloud.y, cloud.size * 0.8, cloud.size * 0.5);
        ellipse(cloud.x - cloud.size * 0.3, cloud.y, cloud.size * 0.7, cloud.size * 0.4);
        
        cloud.x += cloud.speed;
        if (cloud.x > width + cloud.size) {
            cloud.x = -cloud.size;
        }
    }
    
    // Chão (gradiente entre campo e cidade)
    let groundY = height - 50;
    noStroke();
    for (let y = 0; y < 50; y++) {
        let inter = map(y, 0, 50, 0, 1);
        let c = lerpColor(groundColor, color(100, 100, 100, 150), blendFactor);
        fill(red(c), green(c), blue(c), map(y, 0, 50, 200, 255));
        rect(0, groundY + y, width, 1);
    }
    
    // Desenha o campo (lado esquerdo)
    let fieldIntensity = 1 - blendFactor;
    if (fieldIntensity > 0) {
        for (let tree of trees) {
            // Tronco
            fill(139, 69, 19);
            rect(tree.x - 5, tree.y - tree.size, 10, tree.size);
            
            // Folhas
            fill(34, 139, 34, 200 * fieldIntensity);
            for (let i = 0; i < tree.leaves; i++) {
                let leafY = tree.y - tree.size - i * 15;
                let leafSize = tree.size * 0.8 - i * 5;
                ellipse(tree.x, leafY, leafSize, leafSize);
            }
        }
        
        // Grama
        for (let x = 0; x < width * 0.4; x += 10) {
            fill(34, 139, 34, 150 * fieldIntensity);
            let bladeHeight = random(5, 15);
            rect(x, groundY - bladeHeight, 2, bladeHeight);
        }
    }
    
    // Desenha a cidade (lado direito)
    let cityIntensity = blendFactor;
    if (cityIntensity > 0) {
        for (let building of cityBuildings) {
            // Edifício
            fill(lerpColor(color(70, 70, 70), color(50, 50, 80), cityIntensity));
            rect(building.x, groundY - building.height, building.width, building.height);
            
            // Janelas
            fill(255, 255, 100, 200 * cityIntensity);
            let windowSize = 8;
            let windowSpacing = 12;
            let windowsPerRow = floor((building.width - 10) / windowSpacing);
            let rows = floor((building.height - 20) / windowSpacing);
            
            for (let i = 0; i < min(building.windows, windowsPerRow * rows); i++) {
                let row = floor(i / windowsPerRow);
                let col = i % windowsPerRow;
                let x = building.x + 5 + col * windowSpacing;
                let y = groundY - building.height + 10 + row * windowSpacing;
                
                // Aleatoriedade para janelas acesas/apagadas
                if (random() > 0.3 || !isDay) {
                    rect(x, y, windowSize, windowSize);
                }
            }
        }
    }
    
    // Linha divisória interativa
    let divideX = map(blendValue, 0, 100, width * 0.3, width * 0.7);
    stroke(255, 255, 255, 150);
    strokeWeight(2);
    line(divideX, 0, divideX, height);
    
    // Texto interativo
    noStroke();
    fill(255, 255, 255, 200);
    textSize(16);
    textAlign(CENTER, CENTER);
    text("Arraste o controle deslizante para explorar a transição", width/2, 30);
    
    // Ícones de mouse interativo
    if (mouseIsPressed) {
        let iconSize = 30;
        let iconX = constrain(mouseX, iconSize/2, width - iconSize/2);
        let iconY = constrain(mouseY, iconSize/2, height - iconSize/2);
        
        if (blendFactor < 0.5) {
            // Ícone do campo (flor)
            fill(255, 215, 0);
            ellipse(iconX, iconY, iconSize * 0.8, iconSize * 0.8);
            fill(255, 0, 0);
            for (let i = 0; i < 5; i++) {
                let angle = TWO_PI * i / 5;
                let petalX = iconX + cos(angle) * iconSize * 0.6;
                let petalY = iconY + sin(angle) * iconSize * 0.6;
                ellipse(petalX, petalY, iconSize * 0.4, iconSize * 0.4);
            }
        } else {
            // Ícone da cidade (arranha-céu)
            fill(100, 100, 255);
            rect(iconX - iconSize * 0.3, iconY - iconSize * 0.8, iconSize * 0.6, iconSize * 0.8);
            fill(255, 255, 100);
            for (let i = 0; i < 3; i++) {
                rect(iconX - iconSize * 0.2, iconY - iconSize * 0.7 + i * iconSize * 0.25, iconSize * 0.1, iconSize * 0.1);
                rect(iconX + iconSize * 0.1, iconY - iconSize * 0.7 + i * iconSize * 0.25, iconSize * 0.1, iconSize * 0.1);
            }
        }
    }
}

function mouseMoved() {
    // Interação com o mouse - ajusta levemente o blendValue
    blendValue = constrain(map(mouseX, 0, width, 0, 100), 0, 100);
    document.getElementById('blend-slider').value = blendValue;
}